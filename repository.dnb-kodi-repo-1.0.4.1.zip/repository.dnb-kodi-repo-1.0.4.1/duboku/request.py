"""
MIT License

Copyright (c) 2023 groggyegg

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

from re import compile, match, search
from bs4 import BeautifulSoup, SoupStrainer
from requests import Session
from xbmcext import Log, urlparse, getAddonProfilePath
from xbmcext.pymaybe import maybe
from resolveurl.lib import helpers
from os.path import join, exists
import json
import re
import urllib


class Request(object):
    session = Session()
    
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15'}
    addon_profile_path = getAddonProfilePath()
    cookies = { 'cf_clearance':  'VXKYWkIU9oubdvKId6SXrCGwbAZWUxnkGMGRk0jumHE-1708253435-1.0-ATA34QfEAFPcRiJ5gmqtzxjs3nlMyedhf/ypPJlK/wHbb969BSGhniK1ksfA61n/jZyM2vx6TuUFIjZCLYI2NpU=; cf_chl_3=2c04bc1ce097395=',
                'PHPSESSID': '6n3h0fl89aib552m8n0ingarha',
                'cf_chl_3' : '2c04bc1ce097395'}

    @classmethod
    def get(cls, path, headers=None):
        url = 'https:/{}'.format(path)
        url = url.replace('www.duboku.tv', 'tv.gboku.com')
        Log.info('[plugin.video.duboku] GET "{}"'.format(url))
        if headers:  
            response = cls.session.get(url, headers=headers)
        else:
            response = cls.session.get(url, headers=cls.headers)

        if response.status_code != 200:
             #Log.info(f'[plugin.video.duboku] GET {response.text}')
             match = re.search(r'\'(/cdn-cgi/challenge-platform/h/b/orchestrate/chl_page/v1\?ray=[0-9a-fA-F]+)\'', response.text)
             #Log.info(f'[plugin.video.duboku] Resolving JS challenge {response.text}')
             #match = re.search(r'fa: \"(\\/vodplay\\.+)/\",', response.text)
             #match = re.search(r'window._cf_chl_opt=([^;]*)', response.text)
            
             
             Log.info(f'[plugin.video.duboku] Resolving JS challenge {script}')
             if match:
                Log.info(f'[plugin.video.duboku] Resolving JS challenge {url}')
                script = doc.find('script')
                doc = BeautifulSoup(response.text, 'html.parser', parse_only=SoupStrainer('script'))
                '''
                scraper = cloudscraper2.create_scraper(sess=cls.session,
                    browser={
                    'browser': 'firefox',
                    'platform': 'android',
                    'desktop': True
                },
                delay=5,
                debug = True,
                interpreter='nodejs',
                )
                resolve_url = f'https://challenges.cloudflare.com{match.group(1)}'
                Log.info(f'[plugin.video.duboku] Resolving JS challenge {resolve_url}')
                
                #scraper.headers.update(cls.headers)
                #response = scraper.get(url)
                resolve_response = cls.session.get(resolve_url, headers=cls.headers)
                Log.info('[plugin.video.duboku] Cookie Request "{}"'.format(resolve_response.text))
                JavaScriptInterpreter.dynamicImport(
                    'js2py'
                ).solveChallenge(resolve_response.text, cls.netloc(path))
                #Log.info('[plugin.video.duboku] Cookie Request "{}"'.format(cls.cookies))
                '''
                response = cls.session.get(url, headers=cls.headers)

        if response.status_code == 200:
            #    Log.info(response.headers['content-type'])
                if 'image/png' in response.headers['content-type']:
                    return response.content
                #Log.info('[plugin.video.duboku] HTML "{}"'.format(response.text))
                return response.text

        Log.info('[plugin.video.duboku] response.status_code "{}"'.format(response.status_code))
        raise Exception()

    @classmethod
    def post(cls, url, **params):
        #Log.info('[plugin.video.duboku] Cookie Request "{}"'.format(cls.cookies))
        Log.info('[plugin.video.duboku] POST "{}"'.format(url))
        response = cls.session.post(url, params=params, headers=cls.headers, cookies=cls.cookies)
        #cls.cookies = cls.session.cookies.get_dict()
        #Log.info('[plugin.video.duboku] Cookie response "{}"'.format(cls.cookies))

        if response.status_code == 200:
            return

        raise Exception()

    @classmethod
    def netloc(cls, path):
        url = urlparse('https:/{}'.format(path))
        return url.netloc

    @classmethod
    def urlunsplit(cls, netloc, path):
        return path if path.startswith('https://') else 'https:/{}'.format(cls.urljoin(netloc, path))

    @classmethod
    def urljoin(cls, netloc, path):
        return '/{}{}'.format(netloc, path)

    @classmethod
    def vodshow(cls, path):
        netloc = cls.netloc(path)
        parse_only = SoupStrainer(['div', 'ul'], {'class': ['myui-panel myui-panel-bg clearfix', 'myui-page text-center clearfix']})
        doc = BeautifulSoup(cls.get(path), 'html.parser', parse_only=parse_only)
        #Log.info(doc)
        #shows = [cls.urljoin(netloc, a.attrs['href']) for a in doc.find('div', {'class': 'myui-panel_bd'}).find_all('a', {'data-original': True})]
        #shows = [cls.urljoin(netloc, div.find('a', {'class': 'myui-vodlist__thumb lazyload'}).attrs['href']) for div in doc.find('div', {'class': 'myui-vodlist__box'})]

        shows =  [cls.urljoin(netloc, div.find('a', {'class': 'myui-vodlist__thumb lazyload'}).attrs['href']) for div in doc.find_all('div', {'class': 'myui-vodlist__box'})]

        Log.info(shows)
        selected = maybe(doc.find('a', {'class': 'btn btn-warm'})).attrs['href']
        pages = [(cls.urljoin(netloc, a.attrs['href']), a.text) for a in doc.find_all('a', text=['上一页', '下一页']) if a.attrs['href'] != selected]
        return shows, pages

    @classmethod
    def voddetail(cls, path):
        netloc = cls.netloc(path)
        parse_only = SoupStrainer(['div', 'span'], {'class': ['data', 'myui-content__detail', 'myui-content__thumb', 'myui-msg__head text-center', 'myui-msg__body']})
        doc = BeautifulSoup(cls.get(path), 'html.parser', parse_only=parse_only)
        pwd = doc.find('p', {'class': 'text-red'})

        if pwd:
            pwd = match('密码：(.+)', pwd.text).group(1)
            attrs = doc.find('a', {'data-id': True, 'data-mid': True, 'data-type': True}).attrs
            #cls.post(cls.urlunsplit(netloc, '/index.php/ajax/pwd.html'), id=attrs['data-id'], mid=attrs['data-mid'], pwd=pwd, type=attrs['data-type'])
            cls.get(f"/tv.gboku.com/index.php/ajax/pwd.html?id={attrs['data-id']}&mid={attrs['data-mid']}&type={attrs['data-type']}&pwd={pwd}")
            doc = BeautifulSoup(cls.get(path), 'html.parser', parse_only=parse_only)
            Log.info(doc)
        return {'path': path,
                'poster': cls.urlunsplit(netloc, doc.find('img').attrs['data-original']),
                'title': doc.find('h1').text,
                'plot': ' '.join(doc.find('span', {'class': 'data'}).text.replace('&nbsp;', '').split()),
                'category': cls.category(search('分类：(.+)', doc.find('p', {'class': 'data'}).text).group(1)),
                'country': cls.country(search('地区：(.+)', doc.find('p', {'class': 'data'}).text).group(1)),
                'year': int(search('年份：(.+)', doc.find('p', {'class': 'data'}).text).group(1).replace('未知', '0'))}

    @staticmethod
    def category(category):
        return {'日韩剧': 30016,
                '台泰剧': 30018,
                '陆剧': 30015,
                '港剧': 30019,
                '短剧': 30130,
                '英美剧': 30017,
                '综艺': 30004,
                '动漫': 30005,
                '连续剧': 30002,
                '剧情片': 30134,
                '恐怖片': 30135,
                '喜剧片': 30136,
                '战争片': 30137,
                '动作片': 30138,
                '爱情片': 30139,
                '科幻片': 30140,
                '电影': 30003}.get(category, 30112)

    @staticmethod
    def country(countries):
        translate = {'其他': 30112,
                     '内地': 30043,
                     '台湾': 30046,
                     '国产': 30128,
                     '巴西': 30049,
                     '日本': 30054,
                     '法国': 30053,
                     '泰国': 30051,
                     '美国': 30047,
                     '英国': 30048,
                     '荷兰': 30055,
                     '韩国': 30044,
                     '香港': 30045}
        countries = {id for country, id in translate.items() if country in countries}
        return sorted(countries) if countries else [30112]

    @classmethod
    def voddetail_playlist(cls, path):
        doc = BeautifulSoup(cls.get(path), 'html.parser', parse_only=SoupStrainer('a', {'href': compile('#playlist\\d')}))
        return [(a.attrs['href'].strip('#'), a.text) for a in doc.find_all('a')]

    @classmethod
    def voddetail_episode(cls, path, id):
        netloc = cls.netloc(path)
        doc = BeautifulSoup(cls.get(path), 'html.parser', parse_only=SoupStrainer('div', {'id': id}))
        return [(cls.urljoin(netloc, a.attrs['href']), a.text) for a in doc.find_all('a')]

    @classmethod
    def vodplay(cls, path):
        netloc = cls.netloc(path)
        doc = BeautifulSoup(cls.get(path), 'html.parser', parse_only=SoupStrainer('h2'))
        return cls.urljoin(netloc, doc.find('a').attrs['href']), ' '.join(doc.text.split())

    @classmethod
    def downlod_validatae_code_png(cls):
        url = '/www.duboku.tv/verify/index.html'
        png = cls.get(url)
        vc_png_path = join(cls.addon_profile_path, 'vc.png')
        with open(vc_png_path, 'wb') as vc_png:
            vc_png.write(png)
        return vc_png_path

    @classmethod
    def update_cookie(cls, code):
        #url = f'/www.duboku.tv/cdn-cgi/rum?'
        #response = cls.session.get(f'https:/{url}', headers=cls.headers, cookies=cls.cookies)
        #Log.info(response.headers['cf-ray'])
        #loc = response.headers['cf-ray'].split('-')[0]
        #url = f'/www.duboku.tv/cdn-cgi/challenge-platform/h/g/jsd/r/{loc}'
        #cls.post(url)
        url = f'/www.duboku.tv/index.php/ajax/verify_check?type=show&verify={code}'
        Log.info('[plugin.video.duboku] GET "{}"'.format(url))

        cls.get(url)

        #Log.info('[plugin.video.duboku] GET "{}"'.format(cls.cookies))
        #cookies_path = join(cls.addon_profile_path, 'cookies.json')

        #with open(cookies_path, 'w') as cookies_json:
            #cookies_json.write(cls.session.cookies.get_dict())
    @classmethod
    def get_media_url(cls, web_url):
        html = cls.get(web_url)
        #common.logger.log_warning(html)
        host ='tv.gboku.com'
        match = re.search(r'var\s*player_[a-z]{0,4}\s*=\s*([^<]+)', html)

        if match:
            pd = json.loads(match.group(1))
            url = pd.get('url')
            url_next = pd.get('url_next')
            encrypt = pd.get('encrypt')
            php = pd.get('from')
            #Log.info(php)
            headers =  {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15',
                        #'Host': 'tv.gboku.com',
                       'Referer': f'https:/{web_url}'
                       }
            php_url = f'/{host}/static/player/{php}.php'
            #Log.info(php_url)
            php_html = cls.get(php_url, headers=headers)
            #Log.info(php_html)
            #php_match = re.search(r'sign=([0-9a-fA-F]+)', php_html)
            php_match = re.search(r"var\s*encodedRkey\s*=\s*encodeURIComponent\('([^']+)", php_html);

            
            if php_match:
                #Log.info(php_match.group(1))
                sign =  urllib.parse.quote(php_match.group(1), safe='~()*!\'')
            #Log.info(sign)
            if encrypt == 1:
                url = urllib.parse.unquote(url)
                url_next = urllib.parse.unquote(url_next)
            elif encrypt == 2:
                url = urllib.parse.unquote(helpers.duboku_decode(url))
                url_next = urllib.parse.unquote(helpers.duboku_decode(url_next))
            url = url.replace('www.duboku.tv', host)
            url_next = url_next.replace('www.duboku.tv', host)
            Log.info(url)
            #Log.info(url_next)
            if url.startswith('http'):
                return url + f'?sign={sign}' + helpers.append_headers(cls.headers)
            else:
                return url_next + f'?sign={sign}' + helpers.append_headers(cls.headers)

